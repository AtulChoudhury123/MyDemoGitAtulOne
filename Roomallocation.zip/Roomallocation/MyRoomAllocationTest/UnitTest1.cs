﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Roomallocation.Models;

namespace MyRoomAllocationTest
{
    [TestClass]
    public class UnitTest1
    {
        readonly public Roomuser
        [TestMethod]
        public void TestMethod1()
        {

        }
    }
}
