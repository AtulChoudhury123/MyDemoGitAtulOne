﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Roomallocation.Models;
namespace Roomallocation.Controllers
{
    public class AllocationsController : Controller
    {
        // GET: Allocations
        public ActionResult Mainfront()
        {
            return View();
        }
        [HttpGet]
        public ActionResult AddUser()
        {
            Roomuser roomuser = new Roomuser();
            return View(roomuser);

        }
        [HttpPost]
        public ActionResult AddUser(Roomuser roomuser)
        {
            try
            {
                string filename = Path.GetFileNameWithoutExtension(roomuser.ImageFile.FileName);
                string extention = Path.GetExtension(roomuser.ImageFile.FileName);
                filename = filename + DateTime.Now.ToString("yymmssfff") + extention;
                roomuser.Imgpath =  filename;
                filename = Path.Combine(Server.MapPath("~/Image/"), filename);
                roomuser.ImageFile.SaveAs(filename);
                using (DBOneEntities3 dbm1 = new DBOneEntities3())
                {
                    dbm1.Roomusers.Add(roomuser);
                    dbm1.SaveChanges();
                }
                ModelState.Clear();
                ViewBag.alert = "Submitted successfully";
            }
            catch(Exception e)
            {
                ViewBag.alert = "Error in submitting";
                return View("Mainfront");
            }
            return View("Mainfront");

        }

    }
}