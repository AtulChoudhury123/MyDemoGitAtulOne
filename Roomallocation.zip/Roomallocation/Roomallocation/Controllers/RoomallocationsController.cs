﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Roomallocation.Models;
namespace Roomallocation.Controllers
{
    public class RoomallocationsController : Controller
    {
        // GET: Roomallocations

        [HttpGet]
        public ActionResult Addroom()
        {
            Myroom room = new Myroom();
            return View(room);
        }
        [HttpPost]
        public ActionResult AddRoom(Myroom room)
        {
            try
            {
                using (DBOneEntities3 dbm2 = new DBOneEntities3())
                {
                    dbm2.Myrooms.Add(room);
                    dbm2.SaveChanges();

                }
                ModelState.Clear();
                ViewBag.alert = "Successfully Submitted";
            }
            catch(Exception e)
            {
                ViewBag.alert = "Failed to Submit";
            }
            return RedirectToAction("Mainfront", "Allocations");
        }
    }
}