﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Roomallocation.Models;
namespace Roomallocation.Controllers
{
    public class AssignroomsController : Controller
    {
        [HttpGet]
        // GET: Assignrooms
        public ActionResult allDeatils()
        {
            DBOneEntities3 dbm5 = new DBOneEntities3();
            var allnames = (from n in dbm5.Roomusers select n).ToList();
            ViewBag.showuser = allnames;
            return View();
        }

        [HttpPost]
        public ActionResult vacateRooms(string mid,string rid )
        {
            if (mid == rid)
            {
                ViewBag.getmid = mid;
                DBOneEntities3 dbm6 = new DBOneEntities3();
                var getvacate = (from n in dbm6.Myrooms where n.Rmid == null select n).ToList();
                ViewBag.showvacate = getvacate;
                return View();
            }
            else
            {
                DBOneEntities3 dbm7 = new DBOneEntities3();
                var result = (from p in dbm7.Myrooms
                                where p.Rid == rid
                                select p).SingleOrDefault();

                result.Rmid = mid;
                dbm7.SaveChanges();
                return vacateRooms(mid,mid);
            }
               
            
        }

        public ActionResult Mindallocated()
        {
            using (DBOneEntities3 dbm8=new DBOneEntities3())
            {
                var mindsgot = (from x in dbm8.Myrooms where x.Rmid!=null  select x).ToList();
                ViewBag.res = mindsgot;
                return View();
            }
        }
    }
}